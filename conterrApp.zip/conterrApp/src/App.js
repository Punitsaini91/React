import logo from './logo.svg';
import './App.css';
import { Counter } from './container/Counter';

function App() {
  return (<Counter/> );
}

export default App;
