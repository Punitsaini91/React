export const Result=(props)=>
{
    return(<h4>Result is  {props.count}</h4>);
}