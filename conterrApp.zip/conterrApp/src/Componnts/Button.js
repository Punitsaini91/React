import {Button} from '@mui/material'
export const Buttons=({title,opr})=>{
    const buttonClicked = ()=>{
        //console.log('Button Clicked...');
        //props.opr();
        opr();
    }

    return(<Button onClick={buttonClicked}  variant="contained">{title}</Button>)
}