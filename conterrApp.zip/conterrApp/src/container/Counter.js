import {useState} from 'react'

import {  Buttons } from "../Componnts/Button"
import { Result } from "../Componnts/Output"

export const Counter=()=>{
    const [counter, setCounter] = useState(0);
    const plus = ()=>{
        //counter= counter + 1;
        setCounter(counter+1);
        console.log(`I am the Plus ${counter}`);
    }
    const minus = ()=>{
        //counter = counter - 1;
        setCounter(counter-1);
        console.log(`I am the Minus ${counter}`);
    }
    return(
    <div class ="container">
    <h1 class ="alert-info align-centre">CounterApp </h1>
    <Buttons opr={plus} title="+" />
    <Buttons opr={minus} title="-" />
    <Result count={counter}/>
    </div>)
}